--------------------------------------------
ConMas Gateway アップデート手順（Windows用)
--------------------------------------------

※バージョンアップ前に現行バージョンをフォルダごとバックアップすることをお勧めします。

1. メディア内 [\ConMas\gateway_update] フォルダ内のモジュールを元のインストールに上書きします。
   （※サービス登録している場合はアップデート作業前にサービスを停止し、アップデート後に再開してください）

2. メディア内 [\ConMas\Tools] フォルダ内の「node-v12.22.1-x64.msi」を実行し、Node.js を更新します。
   途中、"Tools for Native Modules"画面では、チェックを外してください。ConMas Gateway では不要な開発ツールであるためです。

--------------------------------------------
ConMas Gateway インストール手順（Windows用)
--------------------------------------------

--------------------------------------------
Node.js 環境インストール
--------------------------------------------

付属の「node-v12.22.1-x64.msi」を実行します。
基本的にデフォルトのままウィザードに従ってインストールを完了します。


--------------------------------------------
アプリケーション設定
--------------------------------------------
[\ConMas\gateway] フォルダを任意の場所に配置します。

コマンドプロンプトで[\ConMas\gateway]フォルダに移動し、以下のコマンドを実行します。

> node index.js

（終了するには「Ctrl+C」を入力します）


--------------------------------------------
アプリケーション動作確認
--------------------------------------------

[PowerShell] API実行確認コマンド

Invoke-WebRequest http://localhost:3000/api/v1/getvalue/test? -Headers @{Authorization="Bearer nihuidoaanca88"}


--------------------------------------------
DB接続動作確認
--------------------------------------------


[\ConMas\gateway\config\default.json]ファイルをメモ帳、または、テキストエディタ等で開き、DB接続情報を設定します。
（確認用サンプルではi-Repoterデータベースのユーザーマスターに接続します）


[PowerShell] DB接続確認コマンド
Invoke-WebRequest http://localhost:3000/api/v1/getvalue/pgtest?user_id=conmasadmin -Headers @{Authorization="Bearer nihuidoaanca88"}


--------------------------------------------
外部からの接続
--------------------------------------------

Windowsファイアウォールで、ConMasGatewayの受信ポートを許可します。（デフォルトは３０００番）

任意のポート番号で利用する場合は以下の設定を変更後、任意のポートをファイアウォールで許可します。
[\ConMas\gateway\config\default.json]
    "port": 3000,


--------------------------------------------
サンプルについて
--------------------------------------------

■帳票定義

　各機能を検証いただくためのサンプル帳票定義を以下の配置しています。
　下記XMLをConMasDesinerで取り込むことでご利用いただけます。

    \samples\samplepy_graph\【ConMas Gateway】サンプル定義.xml

■アクションファイル

　サンプル定義で使用するアクションファイルは各種以下フォルダに格納されています。

　\gateway\actions


■サンプルデータベース

　サンプルで使用するデータベースのテーブル作成スクリプトは以下に格納されています。
　データーベースは事前に作成していただく必要があります。

    (PostgreSQL用) \samples\samplepy_graph\pgsql_table.sql
    (SQLServer 用) \samples\samplepy_graph\mssql_table.sql
    (Oracle 用)    \samples\samplepy_graph\oracle_table.sql
    (MySQL  用)    \samples\samplepy_graph\mysql_table.sql

■Pythonスクリプト

　サンプル定義で使用するPythonスクリプトは各種以下フォルダに格納されています。
　サンプルスクリプトが動作するPython環境を事前に構築していただく必要があります。

　\gateway\scripts

　ConMasGatewayとPythonスクリプト間のＩ／Ｆ仕様については、スクリプト内のコメント等をご参照ください。

