import sys
import json
import os

try:
    jsonData = json.loads(sys.stdin.readline())
    pdata = jsonData['data']

    # バーコードから読取った値を利用した処理コードなどを記述する
    code = pdata[0]
    line = int(pdata[1])

    # JSONで返す
    mappings = {"error": "", "mappings": [
            { "item": "" ,"sheet": 1,"cluster":  (line - 2),"type": "string","value" : code},
            { "item": "" ,"sheet": 1,"cluster":  (line - 1),"type": "string","value" : pdata[1]},
            { "sheet": 1,"cluster": line,"type": "SetFocus"}
    ]}
    
    print(json.dumps(mappings))

except Exception as e:
    mappings = {"error": "Pythonでエラー：" + str(e)}
    print(json.dumps(mappings))
