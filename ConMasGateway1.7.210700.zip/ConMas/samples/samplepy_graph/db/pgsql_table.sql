CREATE TABLE public.plcdata1
(
    plc_id character varying(128) COLLATE pg_catalog."default" NOT NULL,
    temp numeric(6,2),
    rpm integer,
    in_amount integer,
    out_amount integer,
    active boolean DEFAULT true,
    update_time timestamp with time zone DEFAULT now(),
    CONSTRAINT plcdata1_pkey PRIMARY KEY (plc_id)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.plcdata1
    OWNER to postgres;


INSERT INTO public.plcdata1(plc_id, temp, rpm, in_amount, out_amount, active, update_time) VALUES ('PLCC', 200.00, 7500, 3000, 1000, true, '2019-09-18 17:00:37.025844+09');
INSERT INTO public.plcdata1(plc_id, temp, rpm, in_amount, out_amount, active, update_time) VALUES ('PLCG', 100.00, 8000, 2500, 350, true, '2019-09-18 17:00:48.978553+09');
INSERT INTO public.plcdata1(plc_id, temp, rpm, in_amount, out_amount, active, update_time) VALUES ('PLCF', 110.00, 3000, 1500, 400, true, '2019-09-18 17:00:44.608837+09');
INSERT INTO public.plcdata1(plc_id, temp, rpm, in_amount, out_amount, active, update_time) VALUES ('PLCD', 250.00, 10000, 5000, 1250, true, '2019-09-18 17:00:39.551942+09');
INSERT INTO public.plcdata1(plc_id, temp, rpm, in_amount, out_amount, active, update_time) VALUES ('PLCE', 160.00, 5500, 4000, 750, true, '2019-09-18 17:00:41.907246+09');
INSERT INTO public.plcdata1(plc_id, temp, rpm, in_amount, out_amount, active, update_time) VALUES ('PLCB', 120.00, 8000, 2000, 800, true, '2019-09-18 17:00:34.754624+09');
INSERT INTO public.plcdata1(plc_id, temp, rpm, in_amount, out_amount, active, update_time) VALUES ('PLCA', 50.00, 5000, 1000, 500, true, '2019-09-18 17:00:32.038442+09');




