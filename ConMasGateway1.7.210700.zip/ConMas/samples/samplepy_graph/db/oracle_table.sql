CREATE TABLE plcdata1 
 (
    plc_id VARCHAR2(10),
    temp NUMBER(6,2),
    rpm NUMBER(6,0),
    in_amount NUMBER(6,0),
    out_amount NUMBER(6,0),
 CONSTRAINT pk1 PRIMARY KEY(plc_id)
 ) 
TABLESPACE USERS;
INSERT INTO plcdata1(plc_id, temp, rpm, in_amount, out_amount) VALUES ('PLCC', 200.00, 7500, 3000, 1000);
INSERT INTO plcdata1(plc_id, temp, rpm, in_amount, out_amount) VALUES ('PLCG', 100.00, 8000, 2500, 350);
INSERT INTO plcdata1(plc_id, temp, rpm, in_amount, out_amount) VALUES ('PLCF', 110.00, 3000, 1500, 400);
INSERT INTO plcdata1(plc_id, temp, rpm, in_amount, out_amount) VALUES ('PLCD', 250.00, 10000, 5000, 1250);
INSERT INTO plcdata1(plc_id, temp, rpm, in_amount, out_amount) VALUES ('PLCE', 160.00, 5500, 4000, 750);
INSERT INTO plcdata1(plc_id, temp, rpm, in_amount, out_amount) VALUES ('PLCB', 120.00, 8000, 2000, 800);
INSERT INTO plcdata1(plc_id, temp, rpm, in_amount, out_amount) VALUES ('PLCA', 50.00, 5000, 1000, 500);
commit;
--select temp, rpm, in_amount, out_amount from plcdata1;
