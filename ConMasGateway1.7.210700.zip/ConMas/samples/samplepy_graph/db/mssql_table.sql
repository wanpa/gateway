USE [gwdb]
GO

/****** Object:  Table [dbo].[plcdata1]    Script Date: 2020/04/15 13:36:55 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[plcdata1](
	[plc_id] [nchar](10) NOT NULL,
	[temp] [numeric](6, 2) NULL,
	[rpm] [int] NULL,
	[in_amount] [int] NULL,
	[out_amount] [int] NULL,
	[update_time] [datetimeoffset](7) NULL,
 CONSTRAINT [PK_plcdata1] PRIMARY KEY CLUSTERED 
(
	[plc_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

INSERT INTO [dbo].[plcdata1] ([plc_id] ,[temp] ,[rpm] ,[in_amount] ,[out_amount] ,[update_time]) VALUES ('PLCC', 200.00, 7500,  3000, 1000, CURRENT_TIMESTAMP)
GO
INSERT INTO [dbo].[plcdata1] ([plc_id] ,[temp] ,[rpm] ,[in_amount] ,[out_amount] ,[update_time]) VALUES ('PLCG', 100.00, 8000,  2500,  350, CURRENT_TIMESTAMP)
GO
INSERT INTO [dbo].[plcdata1] ([plc_id] ,[temp] ,[rpm] ,[in_amount] ,[out_amount] ,[update_time]) VALUES ('PLCF', 110.00, 3000,  1500,  400, CURRENT_TIMESTAMP)
GO
INSERT INTO [dbo].[plcdata1] ([plc_id] ,[temp] ,[rpm] ,[in_amount] ,[out_amount] ,[update_time]) VALUES ('PLCD', 250.00, 10000, 5000, 1250, CURRENT_TIMESTAMP)
GO
INSERT INTO [dbo].[plcdata1] ([plc_id] ,[temp] ,[rpm] ,[in_amount] ,[out_amount] ,[update_time]) VALUES ('PLCE', 160.00, 5500,  4000,  750, CURRENT_TIMESTAMP)
GO
INSERT INTO [dbo].[plcdata1] ([plc_id] ,[temp] ,[rpm] ,[in_amount] ,[out_amount] ,[update_time]) VALUES ('PLCB', 120.00, 8000,  2000,  800, CURRENT_TIMESTAMP)
GO
INSERT INTO [dbo].[plcdata1] ([plc_id] ,[temp] ,[rpm] ,[in_amount] ,[out_amount] ,[update_time]) VALUES ('PLCA', 50.00,  5000,  1000,  500, CURRENT_TIMESTAMP)
GO
