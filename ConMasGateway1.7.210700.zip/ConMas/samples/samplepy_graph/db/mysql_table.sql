create database gwdb;

CREATE TABLE `gwdb`.`plcdata1` (
  `plc_id` VARCHAR(128) NOT NULL,
  `temp` DECIMAL(6,2) NULL,
  `rpm` INT NULL,
  `in_amount` INT NULL,
  `out_amount` INT NULL,
  `active` boolean DEFAULT true,
  `update_time` timestamp DEFAULT CURRENT_TIMESTAMP,
   PRIMARY KEY (`plc_id`));

INSERT INTO gwdb.plcdata1(plc_id, temp, rpm, in_amount, out_amount, active) VALUES ('PLCC', 200.00, 7500, 3000, 1000, true);
INSERT INTO gwdb.plcdata1(plc_id, temp, rpm, in_amount, out_amount, active) VALUES ('PLCG', 100.00, 8000, 2500, 350, true);
INSERT INTO gwdb.plcdata1(plc_id, temp, rpm, in_amount, out_amount, active) VALUES ('PLCF', 110.00, 3000, 1500, 400, true);
INSERT INTO gwdb.plcdata1(plc_id, temp, rpm, in_amount, out_amount, active) VALUES ('PLCD', 250.00, 10000, 5000, 1250, true);
INSERT INTO gwdb.plcdata1(plc_id, temp, rpm, in_amount, out_amount, active) VALUES ('PLCE', 160.00, 5500, 4000, 750, true);
INSERT INTO gwdb.plcdata1(plc_id, temp, rpm, in_amount, out_amount, active) VALUES ('PLCB', 120.00, 8000, 2000, 800, true);
INSERT INTO gwdb.plcdata1(plc_id, temp, rpm, in_amount, out_amount, active) VALUES ('PLCA', 50.00, 5000, 1000, 500, true);



