/**************************
stock_mst
***************************/
--create table
CREATE TABLE stock_mst(
    parts_name varchar2(10) NOT NULL
    ,stock_standard varchar2(2000)
    ,stock_qua int
    ,update_time date DEFAULT sysdate
    ,CONSTRAINT pk_stock_mst PRIMARY KEY(parts_name)
)
TABLESPACE USERS;
--insert
INSERT INTO stock_mst (parts_name,stock_standard,stock_qua) VALUES ('partsA','F123',10);
INSERT INTO stock_mst (parts_name,stock_standard,stock_qua) VALUES ('partsB','G456',8);
INSERT INTO stock_mst (parts_name,stock_standard,stock_qua) VALUES ('partsC','H789',16);
INSERT INTO stock_mst (parts_name,stock_standard,stock_qua) VALUES ('partsD','I147',9);
INSERT INTO stock_mst (parts_name,stock_standard,stock_qua) VALUES ('partsE','J258',20);
/**************************
stock_trn
***************************/
--create table
CREATE TABLE stock_trn(
    parts_name varchar2(10)
    ,stock_standard varchar2(2000)
    ,stock_qua int
    ,akaden_flag int
    ,update_time date DEFAULT sysdate
)
TABLESPACE USERS;
--insert
INSERT INTO stock_trn (parts_name,stock_standard,stock_qua,akaden_flag) VALUES ('partsA','F123',10, 1);
INSERT INTO stock_trn (parts_name,stock_standard,stock_qua,akaden_flag) VALUES ('partsB','G456',8, 1);
INSERT INTO stock_trn (parts_name,stock_standard,stock_qua,akaden_flag) VALUES('partsC','H789',16, 1);
INSERT INTO stock_trn (parts_name,stock_standard,stock_qua,akaden_flag) VALUES('partsD','I147',9, 1);
INSERT INTO stock_trn (parts_name,stock_standard,stock_qua,akaden_flag) VALUES('partsE','J258',20, 1);
INSERT INTO stock_trn (parts_name,stock_standard,stock_qua,akaden_flag) VALUES('partsA','F123',10, 1);
INSERT INTO stock_trn (parts_name,stock_standard,stock_qua,akaden_flag) VALUES('partsB','G456',8, 1);
INSERT INTO stock_trn (parts_name,stock_standard,stock_qua,akaden_flag) VALUES('partsC','H789',16, 1);
INSERT INTO stock_trn (parts_name,stock_standard,stock_qua,akaden_flag) VALUES('partsD','I147',9, 1);
INSERT INTO stock_trn (parts_name,stock_standard,stock_qua,akaden_flag) VALUES('partsE','J258',20, 1);
INSERT INTO stock_trn (parts_name,stock_standard,stock_qua,akaden_flag) VALUES('partsA','F123',-10, 0);
INSERT INTO stock_trn (parts_name,stock_standard,stock_qua,akaden_flag) VALUES('partsB','G456',-8, 0);
INSERT INTO stock_trn (parts_name,stock_standard,stock_qua,akaden_flag) VALUES('partsC','H789',-16, 0);
INSERT INTO stock_trn (parts_name,stock_standard,stock_qua,akaden_flag) VALUES('partsD','I147',-9, 0);
INSERT INTO stock_trn (parts_name,stock_standard,stock_qua,akaden_flag) VALUES('partsE','J258',-20, 0);


