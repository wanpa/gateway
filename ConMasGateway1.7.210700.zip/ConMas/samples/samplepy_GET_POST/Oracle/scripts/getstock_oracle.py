import sys
import json
import numpy
import cx_Oracle

try:

    jsonData = json.loads(sys.stdin.readline())
    reqdata = jsonData['data']
    #Oracle接続情報
    HOST = "192.168.50.125"
    PORT = 1521
    SVC_NM = "xe"    
    USER = 'system' 
    PASS = 'cimtops' 
    # 接続記述子の生成
    dsn = cx_Oracle.makedsn(HOST, PORT, service_name = SVC_NM)
    # SQL生成
    Getmstquery = "SELECT stock_standard,stock_qua FROM stock_mst where parts_name ='%s'"%(reqdata[0],)
    Gettrnquery = "SELECT stock_qua FROM stock_trn where parts_name = '%s'"%(reqdata[0],)
    # コネクションの確立
    with cx_Oracle.connect(USER, PASS, dsn, encoding = "UTF-8") as connection:
        # カーソル生成し# SQL発行
        with connection.cursor() as cursor:    
            # get(mst)
            cursor.execute(Getmstquery)
            rows_mst = cursor.fetchall()[0]
            # get(trn)
            cursor.execute(Gettrnquery)
            rows_trn = cursor.fetchall()

    # カーソル解放
    #cursor.close()
    # コネクションの解放
    #connection.close()
    # トランザクションデータの数量を集計
    trnsum = numpy.sum(rows_trn)
    # マスターとトランザクションの数量の合計
    stock_plan = trnsum + rows_mst[1]

    # JSONで返す
    mappings = {"error": "", "mappings": [
        { "item": "chart1"    ,"sheet": 4,"cluster": 2,"type": "string","value" : str(rows_mst[0])},
        { "item": "chart1"    ,"sheet": 4,"cluster": 3,"type": "string","value" : str(stock_plan)}
        ]}
    print(json.dumps(mappings))

except Exception as e:
  mappings = {"error": "Pythonでエラー：" + str(e)}
  print(json.dumps(mappings))