import numpy
import json
import sys
import cx_Oracle

try:

    jsonData = json.loads(sys.stdin.readline())
    pdata = jsonData['data']

    #Oracle接続情報
    HOST = "192.168.50.125"
    PORT = 1521
    SVC_NM = "xe"    
    USER = 'system' 
    PASS = 'cimtops' 

    # 接続記述子の生成
    dsn = cx_Oracle.makedsn(HOST, PORT, service_name = SVC_NM)
    # SQL生成
    query = "INSERT INTO stock_trn (parts_name,stock_standard,stock_qua,akaden_flag) VALUES ('%s','%s','%s',1)"%(pdata[0],pdata[1],pdata[2])
    # コネクションの確立
    with cx_Oracle.connect(USER, PASS, dsn, encoding = "UTF-8") as connection:
        # カーソル生成し# SQL発行
        with connection.cursor() as cursor:    
            # insert
            cursor.execute(query)
            connection.commit()
    #JSONで返す
    mappings = {"error": "", "mappings": [{ "item": "chart1","sheet": 4,"cluster": 10,"type": "string","value" : "登録完了"}]}
    print(json.dumps(mappings))

except Exception as e:
  mappings = {"error": "Pythonでエラー：" + str(e)}
  print(json.dumps(mappings))