# Oracleからのデータ取得・計算・書き込み

フォルダ配置
- 各フォルダ内のファイルをそれぞれ配置

使用モジュール
- sys
- json
- numpy
- cx_Oracle
※必要に応じてモジュールをインストールしてください
※cx_Oracleを利用するためにはOracle ClientまたはInstant Clientが必要です。
※Oracle Clientのバージョンは11.2以上に対応しています。
※cx_Oracle利用のための環境変数は特にありませんが、Oracle Clientのための環境変数(ORACLE_HOME, NLS_LANG等)は必要です。
※サンプルアプリケーションをテストする前に、SQL*PlusやSQL Developerなどでcx_Oracleインストール対象マシンからOracle Databaseにアクセスできることを確認しておいてください。

テーブル作成
- sqlフォルダ内のファイルを実行してテーブルを作成(stock_mst、stock_trn)

動作①（getstock_oracle.py）
1. 帳票内の【使用部品名称】をPythonへ渡す
2. 受け取った部品名称に当てはまる行を下記のそれぞれのテーブルからデータを取得
    - stock_mst
    - stock_trn
3. stock_trnで抽出した複数行のデータを積算しstock_mstのデータを更に積算
4. 取得したデータ、計算したデータをそれぞれクラスターへ返却

動作②（post_oracle.py）
1. 書き込むデータをpythonへ渡す
    - 使用部品名称
    - 規格
    - 使用数量
    ※本サンプルでは上記３つ
2. stock_trnテーブルへ書き込む
3. 書き込みが完了後『登録完了』の文字列をクラスターへ返却

