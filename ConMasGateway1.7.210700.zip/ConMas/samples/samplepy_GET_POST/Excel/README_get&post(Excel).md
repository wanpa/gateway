# Excelからのデータ取得・計算・書き込み

フォルダ配置
- 各フォルダ内のファイルをそれぞれ配置
- stock_exフォルダはindex.jsと同一階層に配置

使用モジュール
- os
- sys
- json
- glob
- uuid
- shutil
- openpyxl
- numpy
※必要に応じてモジュールをインストールしてください

動作①（getstock_excel.py）
1. 帳票内の【使用部品名称】をPythonへ渡す
2. 受け取った部品名称に当てはまる行を下記のそれぞれのExcelから取得
    - stock_mst.xlsx
    - stock_trn.xlsx
3. stock_trn.xlsxで抽出した複数行のデータの指定列を積算しstock_mst.xlsxのデータを更に積算
4. 取得したデータ、計算したデータをそれぞれクラスターへ返却

動作②（post_excel.py）
1. 書き込むデータをpythonへ渡す
    - 使用部品名称
    - 規格
    - 使用数量
    ※本サンプルでは上記３つ
2. stock_trn.xlsxへ書き込み日時を付与してExcelの最終行へ書き込む
3. 書き込みが完了後『登録完了』の文字列をクラスターへ返却

