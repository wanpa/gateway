
/**************************
stock_mst
***************************/

--create table
CREATE TABLE stock_mst(
    parts_name varchar(10) NOT NULL PRIMARY KEY
    ,stock_standard text
    ,stock_qua int
    ,update_time timestamp with time zone DEFAULT now()
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.stock_mst
    OWNER to postgres;

--insert
INSERT INTO public.stock_mst (parts_name,stock_standard,stock_qua) VALUES ('partsA','F123',10);
INSERT INTO public.stock_mst (parts_name,stock_standard,stock_qua) VALUES ('partsB','G456',8);
INSERT INTO public.stock_mst (parts_name,stock_standard,stock_qua) VALUES ('partsC','H789',16);
INSERT INTO public.stock_mst (parts_name,stock_standard,stock_qua) VALUES ('partsD','I147',9);
INSERT INTO public.stock_mst (parts_name,stock_standard,stock_qua) VALUES ('partsE','J258',20);

/**************************
stock_trn
***************************/

--create table
CREATE TABLE stock_trn(
    parts_name varchar(10)
    ,stock_standard text
    ,stock_qua int
    ,akaden_flag boolean
    ,update_time timestamp with time zone DEFAULT now()
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.stock_trn
    OWNER to postgres;

--insert
INSERT INTO public.stock_trn (parts_name,stock_standard,stock_qua,akaden_flag) VALUES ('partsA','F123',10,'1');
INSERT INTO public.stock_trn (parts_name,stock_standard,stock_qua,akaden_flag) VALUES ('partsB','G456',8,'1');
INSERT INTO public.stock_trn (parts_name,stock_standard,stock_qua,akaden_flag) VALUES('partsC','H789',16,'1');
INSERT INTO public.stock_trn (parts_name,stock_standard,stock_qua,akaden_flag) VALUES('partsD','I147',9,'1');
INSERT INTO public.stock_trn (parts_name,stock_standard,stock_qua,akaden_flag) VALUES('partsE','J258',20,'1');
INSERT INTO public.stock_trn (parts_name,stock_standard,stock_qua,akaden_flag) VALUES('partsA','F123',10,'1');
INSERT INTO public.stock_trn (parts_name,stock_standard,stock_qua,akaden_flag) VALUES('partsB','G456',8,'1');
INSERT INTO public.stock_trn (parts_name,stock_standard,stock_qua,akaden_flag) VALUES('partsC','H789',16,'1');
INSERT INTO public.stock_trn (parts_name,stock_standard,stock_qua,akaden_flag) VALUES('partsD','I147',9,'1');
INSERT INTO public.stock_trn (parts_name,stock_standard,stock_qua,akaden_flag) VALUES('partsE','J258',20,'1');
INSERT INTO public.stock_trn (parts_name,stock_standard,stock_qua,akaden_flag) VALUES('partsA','F123',-10,'0');
INSERT INTO public.stock_trn (parts_name,stock_standard,stock_qua,akaden_flag) VALUES('partsB','G456',-8,'0');
INSERT INTO public.stock_trn (parts_name,stock_standard,stock_qua,akaden_flag) VALUES('partsC','H789',-16,'0');
INSERT INTO public.stock_trn (parts_name,stock_standard,stock_qua,akaden_flag) VALUES('partsD','I147',-9,'0');
INSERT INTO public.stock_trn (parts_name,stock_standard,stock_qua,akaden_flag) VALUES('partsE','J258',-20,'0');
