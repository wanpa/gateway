USE [gwdb_stock]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/**************************
create stock_mst table & insert demodata 
***************************/

CREATE TABLE [dbo].[stock_mst](
	[parts_name] [nchar](10) NOT NULL,
	[stock_standard] [text] NULL,
	[stock_qua] [int] NULL,
	[update_time] [datetime] NULL,
 CONSTRAINT [PK_stock_mst] PRIMARY KEY CLUSTERED 
(
	[parts_name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

INSERT INTO [dbo].[stock_mst] ([parts_name] ,[stock_standard] ,[stock_qua] ,[update_time]) VALUES ('partsA', 'F123', 10, CURRENT_TIMESTAMP)
GO
INSERT INTO [dbo].[stock_mst] ([parts_name] ,[stock_standard] ,[stock_qua] ,[update_time]) VALUES ('partsB', 'G456', 8, CURRENT_TIMESTAMP)
GO
INSERT INTO [dbo].[stock_mst] ([parts_name] ,[stock_standard] ,[stock_qua] ,[update_time]) VALUES ('partsC', 'H789', 16, CURRENT_TIMESTAMP)
GO
INSERT INTO [dbo].[stock_mst] ([parts_name] ,[stock_standard] ,[stock_qua] ,[update_time]) VALUES ('partsD', 'I147', 9, CURRENT_TIMESTAMP)
GO
INSERT INTO [dbo].[stock_mst] ([parts_name] ,[stock_standard] ,[stock_qua] ,[update_time]) VALUES ('partsE', 'J258',  20, CURRENT_TIMESTAMP)
GO

/**************************
create stock_trn table & insert demodata
***************************/

CREATE TABLE [dbo].[stock_trn](
	[parts_name] [nchar](10) NOT NULL,
	[stock_standard] [text] NULL,
	[stock_qua] [int] NULL,
	[akaden_flag] [bit] NULL,
	[update_time] [datetimeoffset](7) NULL,
)

INSERT INTO [dbo].[stock_trn] ([parts_name] ,[stock_standard] ,[stock_qua] ,[akaden_flag] ,[update_time]) VALUES ('partsA','F123',10,'1', CURRENT_TIMESTAMP)
GO
INSERT INTO [dbo].[stock_trn] ([parts_name] ,[stock_standard] ,[stock_qua] ,[akaden_flag] ,[update_time]) VALUES ('partsB','G456',8,'1', CURRENT_TIMESTAMP)
GO
INSERT INTO [dbo].[stock_trn] ([parts_name] ,[stock_standard] ,[stock_qua] ,[akaden_flag] ,[update_time]) VALUES('partsC','H789',16,'1', CURRENT_TIMESTAMP)
GO
INSERT INTO [dbo].[stock_trn] ([parts_name] ,[stock_standard] ,[stock_qua] ,[akaden_flag] ,[update_time]) VALUES('partsD','I147',9,'1', CURRENT_TIMESTAMP)
GO
INSERT INTO [dbo].[stock_trn] ([parts_name] ,[stock_standard] ,[stock_qua] ,[akaden_flag] ,[update_time]) VALUES('partsE','J258',20,'1', CURRENT_TIMESTAMP)
GO
INSERT INTO [dbo].[stock_trn] ([parts_name] ,[stock_standard] ,[stock_qua] ,[akaden_flag] ,[update_time]) VALUES('partsA','F123',10,'1', CURRENT_TIMESTAMP)
GO
INSERT INTO [dbo].[stock_trn] ([parts_name] ,[stock_standard] ,[stock_qua] ,[akaden_flag] ,[update_time]) VALUES('partsB','G456',8,'1', CURRENT_TIMESTAMP)
GO
INSERT INTO [dbo].[stock_trn] ([parts_name] ,[stock_standard] ,[stock_qua] ,[akaden_flag] ,[update_time]) VALUES('partsC','H789',16,'1', CURRENT_TIMESTAMP)
GO
INSERT INTO [dbo].[stock_trn] ([parts_name] ,[stock_standard] ,[stock_qua] ,[akaden_flag] ,[update_time]) VALUES('partsD','I147',9,'1', CURRENT_TIMESTAMP)
GO
INSERT INTO [dbo].[stock_trn] ([parts_name] ,[stock_standard] ,[stock_qua] ,[akaden_flag] ,[update_time]) VALUES('partsE','J258',20,'1', CURRENT_TIMESTAMP)
GO
INSERT INTO [dbo].[stock_trn] ([parts_name] ,[stock_standard] ,[stock_qua] ,[akaden_flag] ,[update_time]) VALUES('partsA','F123',-10,'0', CURRENT_TIMESTAMP)
GO
INSERT INTO [dbo].[stock_trn] ([parts_name] ,[stock_standard] ,[stock_qua] ,[akaden_flag] ,[update_time]) VALUES('partsB','G456',-8,'0', CURRENT_TIMESTAMP)
GO
INSERT INTO [dbo].[stock_trn] ([parts_name] ,[stock_standard] ,[stock_qua] ,[akaden_flag] ,[update_time]) VALUES('partsC','H789',-16,'0', CURRENT_TIMESTAMP)
GO
INSERT INTO [dbo].[stock_trn] ([parts_name] ,[stock_standard] ,[stock_qua] ,[akaden_flag] ,[update_time]) VALUES('partsD','I147',-9,'0', CURRENT_TIMESTAMP)
GO
INSERT INTO [dbo].[stock_trn] ([parts_name] ,[stock_standard] ,[stock_qua] ,[akaden_flag] ,[update_time]) VALUES('partsE','J258',-20,'0', CURRENT_TIMESTAMP)
GO
