# Kintoneからのデータ取得
フォルダ配置
- 各フォルダ内のファイルをそれぞれ配置

動作
1. 帳票で指定したレコード番号をPythonへ渡す
2. 渡されたレコード番号をもとに取得したデータを帳票に返却

接続先は下記を書き換える

```
#Kintone接続先情報
dmain = "cimtops"
app = 323
record = reqdata[0]
API_TOKEN  = "ajXkfrQI1hGvLRTn4ipfKdRhRj9WqNk7n16N6VyF"
URL = "https://%s.cybozu.com/k/v1/record.json?app=%s&id=%s"%(dmain,app,record)
headers = {"X-Cybozu-API-Token": API_TOKEN}
```