USE [gwdb]
GO

/****** Object:  Table [dbo].[plcdata1]    Script Date: 2020/04/15 13:36:55 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[PLCマスター](
	[PLCアイディー] [nvarchar](10) NOT NULL,
	[PLC名] [nvarchar](10),
	[name] [nvarchar](10),
	[表示対象] [nchar](10)
 CONSTRAINT [PK_plcmaster1] PRIMARY KEY CLUSTERED
(
	[PLCアイディー] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

INSERT INTO [dbo].[PLCマスター]([PLCアイディー], [name], [PLC名], [表示対象]) VALUES ('PLCA', 'plc-a', '設備PLC-A', 'リスト1表示');
GO
INSERT INTO [dbo].[PLCマスター]([PLCアイディー], [name], [PLC名], [表示対象]) VALUES ('PLCB', 'plc-b', '設備PLC-B', 'リスト3表示');
GO
INSERT INTO [dbo].[PLCマスター]([PLCアイディー], [name], [PLC名], [表示対象]) VALUES ('PLCC', 'plc-c', '設備PLC-C', 'リスト1表示');
GO
INSERT INTO [dbo].[PLCマスター]([PLCアイディー], [name], [PLC名], [表示対象]) VALUES ('PLCD', 'plc-d', '設備PLC-D', 'リスト3表示');
GO
INSERT INTO [dbo].[PLCマスター]([PLCアイディー], [name], [PLC名], [表示対象]) VALUES ('PLCE', 'plc-e', '設備PLC-E', 'リスト1表示');
GO
INSERT INTO [dbo].[PLCマスター]([PLCアイディー], [name], [PLC名], [表示対象]) VALUES ('PLCF', 'plc-f', '設備PLC-F', 'リスト2表示');
GO
INSERT INTO [dbo].[PLCマスター]([PLCアイディー], [name], [PLC名], [表示対象]) VALUES ('PLCM', null, null, 'リスト1表示');
GO
INSERT INTO [dbo].[PLCマスター]([PLCアイディー], [name], [PLC名], [表示対象]) VALUES ('PLCN', null, null, 'リスト3表示');
GO
