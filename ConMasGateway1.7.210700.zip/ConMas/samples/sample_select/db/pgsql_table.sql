create table public."PLCマスター" (
    "PLCアイディー" varchar(10),
    name varchar(10),
    "PLC名" varchar(10),
    "表示対象" char(20),
    CONSTRAINT plcmst1_pkey PRIMARY KEY ("PLCアイディー")
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public."PLCマスター"
    OWNER to postgres;

INSERT INTO public."PLCマスター"("PLCアイディー", name, "PLC名", "表示対象") VALUES ('PLCA', 'plc-a', '設備PLC-A', 'リスト1表示');
INSERT INTO public."PLCマスター"("PLCアイディー", name, "PLC名", "表示対象") VALUES ('PLCB', 'plc-b', '設備PLC-B', 'リスト3表示');
INSERT INTO public."PLCマスター"("PLCアイディー", name, "PLC名", "表示対象") VALUES ('PLCC', 'plc-c', '設備PLC-C', 'リスト1表示');
INSERT INTO public."PLCマスター"("PLCアイディー", name, "PLC名", "表示対象") VALUES ('PLCD', 'plc-d', '設備PLC-D', 'リスト3表示');
INSERT INTO public."PLCマスター"("PLCアイディー", name, "PLC名", "表示対象") VALUES ('PLCE', 'plc-e', '設備PLC-E', 'リスト1表示');
INSERT INTO public."PLCマスター"("PLCアイディー", name, "PLC名", "表示対象") VALUES ('PLCF', 'plc-f', '設備PLC-F', 'リスト2表示');
INSERT INTO public."PLCマスター"("PLCアイディー", name, "PLC名", "表示対象") VALUES ('PLCM', null, null, 'リスト1表示');
INSERT INTO public."PLCマスター"("PLCアイディー", name, "PLC名", "表示対象") VALUES ('PLCN', null, null, 'リスト3表示');
