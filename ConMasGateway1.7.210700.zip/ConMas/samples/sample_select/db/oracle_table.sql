create table "PLCマスター" (
    "PLCアイディー" nvarchar2(10),
    name nvarchar2(10),
    "PLC名" nvarchar2(10),
    "表示対象" nchar(20)
)
TABLESPACE USERS;

INSERT INTO "PLCマスター"("PLCアイディー", name, "PLC名", "表示対象") VALUES ('PLCA', 'plc-a', '設備PLC-A', 'リスト1表示');
INSERT INTO "PLCマスター"("PLCアイディー", name, "PLC名", "表示対象") VALUES ('PLCB', 'plc-b', '設備PLC-B', 'リスト3表示');
INSERT INTO "PLCマスター"("PLCアイディー", name, "PLC名", "表示対象") VALUES ('PLCC', 'plc-c', '設備PLC-C', 'リスト1表示');
INSERT INTO "PLCマスター"("PLCアイディー", name, "PLC名", "表示対象") VALUES ('PLCD', 'plc-d', '設備PLC-D', 'リスト3表示');
INSERT INTO "PLCマスター"("PLCアイディー", name, "PLC名", "表示対象") VALUES ('PLCE', 'plc-e', '設備PLC-E', 'リスト1表示');
INSERT INTO "PLCマスター"("PLCアイディー", name, "PLC名", "表示対象") VALUES ('PLCF', 'plc-f', '設備PLC-F', 'リスト2表示');
INSERT INTO "PLCマスター"("PLCアイディー", name, "PLC名", "表示対象") VALUES ('PLCM', null, null, 'リスト1表示');
INSERT INTO "PLCマスター"("PLCアイディー", name, "PLC名", "表示対象") VALUES ('PLCN', null, null, 'リスト3表示');

commit;