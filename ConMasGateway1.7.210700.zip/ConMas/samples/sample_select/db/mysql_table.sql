create database if not exists gwdb;

CREATE TABLE `gwdb`.`PLCマスター` (
  `PLCアイディー` NVARCHAR(10) NOT NULL,
  `PLC名` NVARCHAR(10),
  `name` NVARCHAR(10),
  `表示対象` NCHAR(10),
  PRIMARY KEY (`PLCアイディー`)
);

INSERT INTO `gwdb`.`PLCマスター`(`PLCアイディー`, `PLC名`, `name`, `表示対象`) VALUES ('PLCA', '設備PLC-A', 'plc-a', 'リスト1表示');
INSERT INTO `gwdb`.`PLCマスター`(`PLCアイディー`, `PLC名`, `name`, `表示対象`) VALUES ('PLCB', '設備PLC-B', 'plc-b', 'リスト3表示');
INSERT INTO `gwdb`.`PLCマスター`(`PLCアイディー`, `PLC名`, `name`, `表示対象`) VALUES ('PLCC', '設備PLC-C', 'plc-c', 'リスト1表示');
INSERT INTO `gwdb`.`PLCマスター`(`PLCアイディー`, `PLC名`, `name`, `表示対象`) VALUES ('PLCD', '設備PLC-D', 'plc-d', 'リスト3表示');
INSERT INTO `gwdb`.`PLCマスター`(`PLCアイディー`, `PLC名`, `name`, `表示対象`) VALUES ('PLCE', '設備PLC-E', 'plc-e', 'リスト1表示');
INSERT INTO `gwdb`.`PLCマスター`(`PLCアイディー`, `PLC名`, `name`, `表示対象`) VALUES ('PLCF', '設備PLC-F', 'plc-f', 'リスト2表示');
INSERT INTO `gwdb`.`PLCマスター`(`PLCアイディー`, `PLC名`, `name`, `表示対象`) VALUES ('PLCM', null, null, 'リスト1表示');
INSERT INTO `gwdb`.`PLCマスター`(`PLCアイディー`, `PLC名`, `name`, `表示対象`) VALUES ('PLCN', null, null, 'リスト3表示');
