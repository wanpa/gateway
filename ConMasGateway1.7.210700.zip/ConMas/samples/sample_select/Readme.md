# サンプルについて

当サンプルでは単一選択クラスターに対し、DB検索結果を設定する方法を示します。

## 帳票定義

機能を検証いただくためのサンプル帳票定義を以下の配置しています。
下記XMLをConMasDesinerで取り込むことでご利用いただけます。

    【ConMas Gateway】サンプル定義.xml

## アクションファイル

サンプル定義で使用するアクションファイルは以下フォルダに格納されています。接尾辞で対応するDBを示しています（PostgreSQL であれば _pg 等）。
動作させるためには、gateway\actions にコピーする必要があります。

    .\actions

## サンプルデータベース

サンプルで使用するデータベースのテーブル作成スクリプトは以下に格納されています。
データーベース・インスタンスは事前に作成していただく必要があります。

    (PostgreSQL用)    .\db\pgsql_table.sql
    (SQL Server用)    .\db\mssql_table.sql
    (Oracle用)        .\db\oracle_table.sql
    (MySQL=MariaDB用) .\db\mssql_table.sql

以上です。
