# Excel関数

**フォルダ配置**
各フォルダ内のファイルをそれぞれ配置

**動作**
Pythonを利用し帳票上のクラスター値をExcel関数で計算し結果をi-Reporter帳票へ返却

**使用モジュール**
全関数共通
- json
- sys
- math

TEXT関数
- datetime
- japanera

**サンプル提供関数**
- TEXT関数（すべての表示形式には対応しておりません）
- LOG関数
- MOD関数
- POWER関数
- SQRT関数
---
---
## 設定方法

### TEXT関数

アクションクラスター（Gateway連携）にURLを設定

```
http://localhost:3000/api/v1/getvalue/exfunc_text?type=date&val={1,5}&arg=yyyy&sheet=1&cluster=1
```

1. アクションファイルの指定　[アクションファイルの指定方法について](https://cimtops.ba.accelatech.com/user_files/8/25318_543_ConMasGateway_Manual.pdf?c=25319&dlog=true&tc=25318?ts=1600139811766#page=16)
- exfunc_text

2. URLクエリパラメータ、**type**に表示形式を下記から選択
- date（日付）
- zero_pad（先頭0埋め）
- comma（3桁区切り）
- per（%変換）
- digit（表示桁指定）
- digit_decimal（小数点以下の桁指定）
- digit_embedded（文字埋め）

3. URLクエリパラメータ、**val**にi-Reporterのクラスターを指定
※i-Reporterの日付書式はyymmddを選択

4. typeにdateを選択した場合URLクエリパラメータ、**arg**に表示形式を指定
※対応表示形式は以下

日付
- yyyy
- yy
- m
- mm
- mmm   
- mmmm
- d
- dd

曜日
- ddd
- dddd

和暦
- e
- ee
- gg
- ggg

※type=data以外は変数（~~&arg=~~）も削除（ex:commaの場合）
```
http://localhost:3000/api/v1/getvalue/exfunc_text?type=comma&val={1,5}&sheet=1&cluster=1
```
5. URLクエリパラメータ、**sheet**に返却先のsheet番号を指定
6. URLクエリパラメータ、**cluster**に返却先のクラスターインデックスを指定

※1.text.pyのvalueの型は、適宜変更してご利用ください
※2.0埋め個数・桁指定・文字埋めの桁指定はtext.pyを書き換えてご利用ください
※3.月・曜日を日本語にしたい場合はロケールを変更してください（デフォルトは英語）


### log関数
アクションクラスター（Gateway連携）にURLを設定します
```
http://localhost:3000/api/v1/getvalue/exfunc_log?val1={1,22}&val2={1,23}&sheet=1&cluster=19
```
1. アクションファイルの指定　[アクションファイルの指定方法について](https://cimtops.ba.accelatech.com/user_files/8/25318_543_ConMasGateway_Manual.pdf?c=25319&dlog=true&tc=25318?ts=1600139811766#page=16)
- exfunc_log

2. URLクエリパラメータ、**val1**にi-Reporterのクラスターを指定
3. URLクエリパラメータ、**val2**にi-Reporterのクラスターを指定
4. URLクエリパラメータ、**sheet**に返却先のsheet番号を指定
5. URLクエリパラメータ、**cluster**に返却先のクラスターインデックスを指定


### mod関数
アクションクラスター（Gateway連携）にURLを設定します
```
http://localhost:3000/api/v1/getvalue/exfunc_mod?val1={1,32}&val2={1,33}&sheet=1&cluster=29
```
1. アクションファイルの指定　[アクションファイルの指定方法について](https://cimtops.ba.accelatech.com/user_files/8/25318_543_ConMasGateway_Manual.pdf?c=25319&dlog=true&tc=25318?ts=1600139811766#page=16)
- exfunc_mod

2. URLクエリパラメータ、**val1**にi-Reporterのクラスターを指定（数値）
3. URLクエリパラメータ、**val2**にi-Reporterのクラスターを指定（除数）
4. URLクエリパラメータ、**sheet**に返却先のsheet番号を指定
5. URLクエリパラメータ、**cluster**に返却先のクラスターインデックスを指定


### power関数
アクションクラスター（Gateway連携）にURLを設定します
```
http://localhost:3000/api/v1/getvalue/exfunc_power?val1={1,12}&val2={1,13}&sheet=1&cluster=9
```
1. アクションファイルの指定　[アクションファイルの指定方法について](https://cimtops.ba.accelatech.com/user_files/8/25318_543_ConMasGateway_Manual.pdf?c=25319&dlog=true&tc=25318?ts=1600139811766#page=16)
- exfunc_power

2. URLクエリパラメータ、**val1**にi-Reporterのクラスターを指定（数値）
3. URLクエリパラメータ、**val2**にi-Reporterのクラスターを指定（指数）
4. URLクエリパラメータ、**sheet**に返却先のsheet番号を指定
5. URLクエリパラメータ、**cluster**に返却先のクラスターインデックスを指定


### sqrt関数

アクションクラスター（Gateway連携）にURLを設定します
```
http://localhost:3000/api/v1/getvalue/exfunc_sqrt?val1={1,3}&sheet=1&cluster=0
```
1. アクションファイルの指定　[アクションファイルの指定方法について](https://cimtops.ba.accelatech.com/user_files/8/25318_543_ConMasGateway_Manual.pdf?c=25319&dlog=true&tc=25318?ts=1600139811766#page=16)
- exfunc_sqrt

2. URLクエリパラメータ、**val1**にi-Reporterのクラスターを指定
3. URLクエリパラメータ、**sheet**に返却先のsheet番号を指定
4. URLクエリパラメータ、**cluster**に返却先のクラスターインデックスを指定
