select
   temp
 , rpm
 , in_amount
 , out_amount
 from plcdata1
 