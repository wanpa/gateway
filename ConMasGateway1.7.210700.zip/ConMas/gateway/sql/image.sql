select
   rep_sheet_id
 , cluster_id
 , cluster_name
 ,image_file
 from view_rep_cluster
 where rep_sheet_id =152
 and cluster_id = 9
